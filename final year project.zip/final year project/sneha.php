<?php
	  $hostname = "localhost";
	  $username = "root";
	  $password = "";
	  $dbname = "sneha";

	  $conn = mysqli_connect($hostname, $username, $password, $dbname);
	 
	 if(!$conn){
		echo "Database connection error".mysqli_connect_error();
	  }

    $fname = mysqli_real_escape_string($conn, $_POST['fname']);
    $lname = mysqli_real_escape_string($conn, $_POST['lname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $number = mysqli_real_escape_string($conn, $_POST['number']);
	$url = "login.php";
	
    $sql = mysqli_query($conn, "INSERT INTO `login`(`PersonID`, `FirstName`, `LastName`, `contact`, `gmail`, `pass`) VALUES ('','$fname','$lname','$number','$email','$password')");
        
    if($sql){
        header('Location: '.$url);
    }else{
		echo "please fill all spaces";
	}
?>