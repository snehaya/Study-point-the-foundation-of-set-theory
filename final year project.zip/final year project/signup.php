<!DOCTYPE HTML>
<?php
  $hostname = "localhost";
  $username = "root";
  $password = "";
  $dbname = "sneha";

  $conn = mysqli_connect($hostname, $username, $password, $dbname);
  if(!$conn){
    echo "Database connection error".mysqli_connect_error();
  }
?>
<HTML>
	<head>
		<!-- external stylesheet -->
		<link rel="stylesheet" href="style.css">
		
		<title>StudyPoint.com</title>
		
		<link rel="icon" href="images\logo.jpg">
		
		<!-- font-styles -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="shortcut icon" href="/favicon_io/favicon-16x16.png" type="image/x-icon">
		
		<!-- fa fa icons -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	
	</head>
	<body>
		<!-- container div -->
		<div class="container-s">
			<div class="signup">
				<form action="sneha.php" method="POST" autocomplete="off">
					
					<legend>Registration</legend>
					
						<label class="label">Enter Your First Name :</label><br>
						<input type="text" placeholder="Enter Your First Name" class="input" name="fname" id="fname"><br>
		
						<label class="label">Enter Your Last Name :</label><br>
						<input type="text" placeholder="Enter Your Last Name"  class="input" name="lname" id="lname"><br>
				

						<label class="label">Enter Your Contact Number :</label><br>
						<input type="number" placeholder="Enter Your Contact Number"  class="input" name="number" id="cno"><br>
	

						<label class="label">Enter Your Gmail :</label><br>
						<input type="email" placeholder="Enter Your Gmail"  class="input" id="email" name="email"><br>

	
						<label for="pwd" class="label">Password:</label>
						<input type="password" id="pwd" class="input" placeholder="Enter your password"><br>


						<label for="pwd" class="label">Confirm Password:</label>
						<input type="password" id="pwd" name="password" class="input" placeholder="Enter your password"><br>
		
		
						<a href="">
							<input type="submit" value="Register" class="register" /><br>
						</a>
		
					<a href="login.html" class="log-sign">Already having account, Login</a>
				
				</form>
                
                </div>
		</div>
	</body>
</html>