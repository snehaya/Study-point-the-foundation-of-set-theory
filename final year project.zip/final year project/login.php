<!DOCTYPE HTML>
<?php
	  $hostname = "localhost";
	  $username = "root";
	  $password = "";
	  $dbname = "sneha";

	  $conn = mysqli_connect($hostname, $username, $password, $dbname);
	 
	 if(!$conn){
		echo "Database connection error".mysqli_connect_error();
	  }
?>
<HTML>
	<head>
		<!-- external stylesheet -->
		<link rel="stylesheet" href="style.css">
		
		<title>StudyPoint.com</title>
		
		<link rel="icon" href="images\logo.jpg">
		
		<!-- font-styles -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="shortcut icon" href="/favicon_io/favicon-16x16.png" type="image/x-icon">
		
		<!-- fa fa icons -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	
	</head>
	<body>
		<!-- container div -->
		<div class="container">
			<div class="login">
				<form action="" method="POST">
					<legend>Login</legend>
	
					<label class="label">Enter Your Gmail :</label><br>
					<input type="email" placeholder="Enter Your Gmail" name="gmail" required class="input" id="email"><br>
					<label for="pwd" class="label">Password:</label>
					<input type="password" id="pwd" name="password" class="input" placeholder="Enter your password"><br>
					
	
					<button value="Login" name="log" class="register">Login</button><br>
				
					<a href="signup.php" class="log-sign">Don't having account, create account</a>
					
				</form>
				
				<script>
					function pass(){
						var pass = document.getElementById('pwd').value;
						str = pass.toString();
						if(str.length <= 9){
							alert("please insert at least 8 characters.")
						}
						
					}
				</script>
			</div>
		</div>
		<?php
			if(isset($_POST["log"])){	
				 $sql = mysqli_query($conn, "select * from `login`");
				 $url = "quiz.html";
				 
				 while( $row = mysqli_fetch_assoc($sql)){
					if($row['gmail'] == $_POST["gmail"] && $row['pass'] == $_POST["password"]){
						header('Location: '.$url);
					}else{
						echo "<script>alert('please insert correct information')</script>";
					}
				 }
				
			}
		?>
	</body>
</html>